<body>
  <div id="container">
  <?php

include '_includes/config.php';
include ABSOLUTE_PATH . '/_includes/header.inc.php';


 ?>


		<?php

		include ABSOLUTE_PATH .'/_includes/footer.inc.php';

		 ?>
   </div>
 </div>

</body>
