<?php
    define("ABSOLUTE_PATH", "/home/treust/htdocs/ex1/php_includes");

    define("URL_ROOT", "http://corsair.cs.iupui.edu:21931/ex1/php_includes");
 ?>
