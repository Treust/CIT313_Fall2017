<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>CIT 31300 - Week 2 - PHP review</title>
<link rel="stylesheet" type="text/css" href="<?= URL_ROOT ?>/main.css"/>
</head>
<div id="header">
  <h1>
CIT 31300 - Week 2 - PHP review
  </h1>
</div>
