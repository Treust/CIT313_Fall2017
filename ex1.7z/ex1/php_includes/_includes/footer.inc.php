<html>
	<div id="footer">
		Copyright © Tom's stuff, 2017
	</div>
